INSERT into
	FDW_TABLES_DB.OA3NF_GL_BALANCES_COR_S (	
    ACTUAL_FLAG                   
	, BEGIN_BALANCE_CR              
	, BEGIN_BALANCE_CR_BEQ          
	, BEGIN_BALANCE_CR_BEQ_CORR     
	, BEGIN_BALANCE_DR              
	, BEGIN_BALANCE_DR_BEQ          
	, BEGIN_BALANCE_DR_BEQ_CORR     
	, CHART_OF_ACCOUNT_ID           
	, CURRENCY_CD                   
	, ENCUMBRANCE_TYPE_ID           
	, FINANCIAL_PLAN_ID             
	, GL_PERIOD_ID                  
	, LAST_UPDATE_DTTM              
	, PERIOD_NET_CR                 
	, PERIOD_NET_CR_BEQ             
	, PERIOD_NET_CR_BEQ_CORR        
	, PERIOD_NET_DR                 
	, PERIOD_NET_DR_BEQ             
	, PERIOD_NET_DR_BEQ_CORR        
	, PERIOD_TO_DATE_ADB            
	, PERIOD_YEAR                   
	, PROJECT_TO_DATE_CR            
	, PROJECT_TO_DATE_CR_BEQ        
	, PROJECT_TO_DATE_DR            
	, PROJECT_TO_DATE_DR_BEQ        
	, QUARTER_TO_DATE_ADB           
	, QUARTER_TO_DATE_CR            
	, QUARTER_TO_DATE_CR_BEQ        
	, QUARTER_TO_DATE_DR            
	, QUARTER_TO_DATE_DR_BEQ        
	, SET_OF_BOOKS_ID               
	, TRANSLATED_FLAG               
	, YEAR_TO_DATE_ADB              
	, BEGIN_BALANCE_CR_CORR         
	, BEGIN_BALANCE_DR_CORR         
	, PERIOD_NET_CR_CORR            
	, PERIOD_NET_DR_CORR
  , PERIOD_NUM /*CBS*/
	, QUARTER_TO_DATE_CR_CORR            
	, QUARTER_TO_DATE_CR_BEQ_CORR   )
SELECT
	dt4.ACTUAL_FLAG                   
	, BEGIN_BALANCE_CR              
	, BEGIN_BALANCE_CR_BEQ          
	, BEGIN_BALANCE_CR_BEQ_CORR     
	, BEGIN_BALANCE_DR              
	, BEGIN_BALANCE_DR_BEQ          
	, BEGIN_BALANCE_DR_BEQ_CORR     
	, dt4.CHART_OF_ACCOUNT_ID           
	, dt4.CURRENCY_CD                   
	, dt4.ENCUMBRANCE_TYPE_ID           
	, dt4.FINANCIAL_PLAN_ID             
	, GL_PERIOD_ID                  
	, LAST_UPDATE_DTTM              
	, PERIOD_NET_CR                 
	, PERIOD_NET_CR_BEQ             
	, PERIOD_NET_CR_BEQ_CORR        
	, PERIOD_NET_DR                 
	, PERIOD_NET_DR_BEQ             
	, PERIOD_NET_DR_BEQ_CORR        
	, PERIOD_TO_DATE_ADB            
	, dt4.PERIOD_YEAR                   
	, PROJECT_TO_DATE_CR            
	, PROJECT_TO_DATE_CR_BEQ        
	, PROJECT_TO_DATE_DR            
	, PROJECT_TO_DATE_DR_BEQ        
	, QUARTER_TO_DATE_ADB           
	, QUARTER_TO_DATE_CR            
	, QUARTER_TO_DATE_CR_BEQ        
	, QUARTER_TO_DATE_DR            
	, QUARTER_TO_DATE_DR_BEQ        
	, dt4.SET_OF_BOOKS_ID               
	, TRANSLATED_FLAG               
	, YEAR_TO_DATE_ADB              
	, BEGIN_BALANCE_CR_CORR         
	, BEGIN_BALANCE_DR_CORR         
	, PERIOD_NET_CR_CORR            
	, PERIOD_NET_DR_CORR 
  , PERIOD_NUM /*CBS*/ 
	, QUARTER_TO_DATE_CR_CORR            
	, QUARTER_TO_DATE_CR_BEQ_CORR            
FROM
(	
/*Start of DT4*/
SELECT
		NFB2.Actual_Flag
		, NFB2.BEGIN_BALANCE_CR /*OV */
		/*BR200 - correct the Begin_Balances_CR_BEQ*/
		, CASE 
			WHEN NFB2.CURRENCY_CD = dt3.Currency_code  
				THEN (NFB2.BEGIN_BALANCE_CR - dt2.Sum_BEGIN_BALANCE_CR_BEQ)
			ELSE
				NFB2.BEGIN_BALANCE_CR	
		END   (Named BEGIN_BALANCE_CR_CORR)
		, NFB2.BEGIN_BALANCE_CR_BEQ  /*OV*/
		/*BR400 - source the BEGIN_BALANCE_CR_BEQ from the Sum_CRCT_BEGIN_BALANCE_CR*/
		, CASE 
			WHEN NFB2.CURRENCY_CD = dt3.Currency_code  
				THEN BEGIN_BALANCE_CR_CORR 
			ELSE
				/*dt2.Sum_BEGIN_BALANCE_CR_BEQ	*/
				/*fix 2008-02-19*/
				BEGIN_BALANCE_CR_BEQ
		END   (Named BEGIN_BALANCE_CR_BEQ_CORR)

		, NFB2.BEGIN_BALANCE_DR /*OV BEGIN_BALANCE_DR*/
		, NFB2.BEGIN_BALANCE_DR_BEQ  /*OV*/
		/*BR200 - correct the Begin_Balances_DR_BEQ*/
		, CASE 
			WHEN NFB2.CURRENCY_CD = dt3.Currency_code  
				THEN (NFB2.BEGIN_BALANCE_DR - dt2.Sum_BEGIN_BALANCE_DR_BEQ)
			ELSE
				NFB2.BEGIN_BALANCE_DR	
		END   (Named BEGIN_BALANCE_DR_CORR)

		/*BR400 - source the BEGIN_BALANCE_DR_BEQ from the CRCT_BEGIN_BALANCE_DR*/
		, CASE 
			WHEN NFB2.CURRENCY_CD = dt3.Currency_code  
				/*dt2.Sum_BEGIN_BALANCE_DR_BEQ */
				/*fix 2008-02-19*/
				THEN BEGIN_BALANCE_DR_CORR
			ELSE
				NFB2.BEGIN_BALANCE_DR_BEQ	
		END   (Named BEGIN_BALANCE_DR_BEQ_CORR)

		, NFB2.CHART_OF_ACCOUNT_ID
		, NFB2.CURRENCY_CD
		, NFB2.ENCUMBRANCE_TYPE_ID
		, NFB2.FINANCIAL_PLAN_ID
		, NFB2.GL_PERIOD_ID
		, NFB2.LAST_UPDATE_DTTM
		, NFB2.PERIOD_NET_CR   /* OV */		
		, NFB2.PERIOD_NET_CR_BEQ /*OV */
		/*BR300 */
		/*correct the PERIOD_NET_CR*/
		, CASE 
			WHEN NFB2.CURRENCY_CD = dt3.Currency_code  
				THEN (NFB2.PERIOD_NET_CR - dt2.Sum_PERIOD_NET_CR_BEQ ) 
			ELSE
				NFB2.PERIOD_NET_CR	
		END   (Named PERIOD_NET_CR_CORR)

		/*BR500 - source the Period_Net_CR_BEQ_CORR  from the Period_Net_CR_BEQ for corrected records*/
		, CASE 
			WHEN NFB2.CURRENCY_CD = dt3.Currency_code  
				/*THEN dt2.Sum_PERIOD_NET_CR_BEQ*/
				/*fix 20080219*/
				THEN PERIOD_NET_CR_CORR
			ELSE
				NFB2.Period_Net_CR_BEQ	
		END   (Named Period_Net_CR_BEQ_CORR)

		, NFB2.PERIOD_NET_DR   /* OV */	
		, NFB2.PERIOD_NET_DR_BEQ /*OV */
		
		/*BR300 - correct the BEGIN_BALANCE_DR_BEQ*/
		, CASE 
			WHEN NFB2.CURRENCY_CD = dt3.Currency_code  
				THEN (NFB2.PERIOD_NET_DR - dt2.Sum_PERIOD_NET_DR_BEQ ) 
			ELSE
				NFB2.PERIOD_NET_DR	
		END   (Named PERIOD_NET_DR_CORR)

		/*BR500 - source the Period_Net_DR_BEQ_CORR  from the Period_Net_DR_BEQ*/
		, CASE 
			WHEN NFB2.CURRENCY_CD = dt3.Currency_code  
				THEN 
				/*dt2.Sum_PERIOD_NET_DR_BEQ*/
				/*fix 20080219*/
				PERIOD_NET_DR_CORR
			ELSE
				NFB2.Period_Net_DR_BEQ
		END   (Named Period_Net_DR_BEQ_CORR)

		, NFB2.PERIOD_TO_DATE_ADB
		, NFB2.PERIOD_YEAR
		
		, NFB2.PROJECT_TO_DATE_CR
		, NFB2.PROJECT_TO_DATE_CR_BEQ
		, NFB2.PROJECT_TO_DATE_DR
		, NFB2.PROJECT_TO_DATE_DR_BEQ
		
		, NFB2.QUARTER_TO_DATE_ADB
		, NFB2.QUARTER_TO_DATE_CR
		, NFB2.QUARTER_TO_DATE_CR_BEQ
		, NFB2.QUARTER_TO_DATE_DR
		, NFB2.QUARTER_TO_DATE_DR_BEQ
		
		, NFB2.SET_OF_BOOKS_ID
		, NFB2.TRANSLATED_FLAG
		, NFB2.YEAR_TO_DATE_ADB

		, CASE 
			WHEN NFB2.CURRENCY_CD = dt3.Currency_code  then 'Y' 
		ELSE 'N'
		END  (Named Balance_Corr_F)

		, NFB2.PERIOD_NUM /*CBS*/
		/*CBS - correct the QUARTER_TO_DATE_CR*/
		, CASE 
			WHEN NFB2.CURRENCY_CD = dt3.Currency_code  
				THEN (NFB2.QUARTER_TO_DATE_CR - dt2.Sum_QUARTER_TO_DATE_CR ) 
			ELSE
				NFB2.QUARTER_TO_DATE_CR	
		END   (Named QUARTER_TO_DATE_CR_CORR)


		/*CBS - correct the QUARTER_TO_DATE_CR_BEQ*/
		, CASE 
			WHEN NFB2.CURRENCY_CD = dt3.Currency_code  
				THEN (NFB2.QUARTER_TO_DATE_CR - dt2.Sum_QUARTER_TO_DATE_CR_BEQ ) 
			ELSE
				NFB2.QUARTER_TO_DATE_CR	
		END   (Named QUARTER_TO_DATE_CR_BEQ_CORR)

FROM 
	FDW_TABLES_DB.OA3NF_GL_BALANCES_ 		NFB2
INNER  JOIN
	/*get the SOB Reporting SOB */
		(
		/*this dt serves two purposes*/
		/*1. provide the description of the SOB*/
		/*2. provide the relationship between the primary  book and the MRC book */ 
		SELECT
			SOB1.Set_of_books_id
			, SOB1.Currency_cd as Currency_code
			, SOB1.Set_of_Books_Name
			--, SOB1.REFOA3NF_SET_OF_BOOKS_Id (Named ReportingOA3NF_SET_OF_BOOKS_Id)
		FROM
			FDW_TABLES_DB.OA3NF_SET_OF_BOOKS  SOB1
			where SOB1.Set_of_books_name  in ('CBS Studios USD','CBS Distribution USD')  -- Added By 
		)  dt3
ON NFB2.SET_OF_BOOKS_ID = dt3.Set_of_books_id
INNER JOIN
/*start of dt2*/
( 
/*BR100*/
/*calc the correct DR and CR amount in the currency of the SOB */
/*this will be used to calc the corrent balance for both CR and DR of the SOB currency */
SELECT
		 NFB1.CHART_OF_ACCOUNT_ID
		, NFB1.SET_OF_BOOKS_ID
		, NFB1.GL_PERIOD_ID
/* FIX FOR BUDGETS */
		,NFB1.FINANCIAL_PLAN_ID
/* FIX FOR BUDGETS */
		, sum(case when NFB1.Currency_cd = 'USD' Then '0' ELSE NFB1.BEGIN_BALANCE_CR_BEQ END) (Named sum_BEGIN_BALANCE_CR_BEQ) -- Added Case when statement By 
 		, sum(case when NFB1.Currency_cd = 'USD' Then '0' ELSE NFB1.BEGIN_BALANCE_DR_BEQ END ) (Named sum_BEGIN_BALANCE_DR_BEQ)
		, sum(case when NFB1.Currency_cd = 'USD' Then '0' ELSE NFB1.PERIOD_NET_CR_BEQ END ) (Named sum_PERIOD_NET_CR_BEQ)
		, sum(case when NFB1.Currency_cd = 'USD' Then '0' ELSE NFB1.PERIOD_NET_DR_BEQ END ) (Named sum_PERIOD_NET_DR_BEQ)
		/*new 20080207 */
		, sum(case when NFB1.Currency_cd = 'USD' Then '0' ELSE QUARTER_TO_DATE_CR_BEQ END )  (Named sum_QUARTER_TO_DATE_CR_BEQ)
		, sum(case when NFB1.Currency_cd = 'USD' Then '0' ELSE QUARTER_TO_DATE_DR_BEQ END )  (Named sum_QUARTER_TO_DATE_DR_BEQ)
		, sum(case when NFB1.Currency_cd = 'USD' Then '0' ELSE PROJECT_TO_DATE_CR_BEQ END ) (Named sum_PROJECT_TO_DATE_CR_BEQ )
		, sum(case when NFB1.Currency_cd = 'USD' Then '0' ELSE PROJECT_TO_DATE_DR_BEQ END ) (Named sum_PROJECT_TO_DATE_DR_BEQ )
		, sum(case when NFB1.Currency_cd = 'USD' Then '0' ELSE QUARTER_TO_DATE_CR END )  (Named sum_QUARTER_TO_DATE_CR)
FROM 
	FDW_TABLES_DB.OA3NF_GL_BALANCES_ 		NFB1
INNER JOIN
	/*get the SOB Reporting SOB */
		(
		/*this dt serves two purposes*/
		/*1. provide the description of the SOB*/
		/*2. provide the relationship between the primary  book and the MRC book */ 
		SELECT
			SOB1.Set_of_books_id
			, SOB1.Currency_cd as Currency_code
			, SOB1.Set_of_Books_Name
			--, SOB1.REFOA3NF_SET_OF_BOOKS_Id (Named ReportingOA3NF_SET_OF_BOOKS_Id)
		FROM
			FDW_TABLES_DB.OA3NF_SET_OF_BOOKS  SOB1
			where SOB1.Set_of_books_name  in ('CBS Studios USD','CBS Distribution USD')  -- Added By  
		)  dt1

ON NFB1.SET_OF_BOOKS_ID = dt1.Set_of_books_id 
--AND NFB1.SET_OF_BOOKS_ID in (2248,2249) --  Comment
--and NFB1.currency_cd <> dt1.Currency_code --  Comment (Join Not Required)
Group by 1,2,3
/* FIX FOR BUDGETS */
,4
/* FIX FOR BUDGETS */
) as dt2

ON dt2.Chart_Of_Account_Id = NFB2.Chart_Of_Account_Id
AND dt2.Set_Of_Books_Id =  NFB2.Set_Of_Books_Id
AND dt2.GL_Period_Id = NFB2.GL_Period_Id
/* FIX FOR BUDGETS */
AND dt2.financial_plan_id = nfb2.financial_plan_id
/* FIX FOR BUDGETS */
/* Correction requried - ie currency equal sob currency*/
WHERE	Balance_Corr_F = 'Y' /*only insert rows that need to corrected*/
) as dt4
/* CDC Update */
, 
FDW_TABLES_DB.OA3NF_GL_BALANCES_CDC 
WHERE dt4.ACTUAL_FLAG  = FDW_TABLES_DB.OA3NF_GL_BALANCES_CDC.ACTUAL_FLAG 
AND        dt4.CHART_OF_ACCOUNT_ID = FDW_TABLES_DB.OA3NF_GL_BALANCES_CDC.CHART_OF_ACCOUNT_ID 
AND        dt4.CURRENCY_CD = FDW_TABLES_DB.OA3NF_GL_BALANCES_CDC.CURRENCY_CD 
AND        dt4.ENCUMBRANCE_TYPE_ID = FDW_TABLES_DB.OA3NF_GL_BALANCES_CDC.ENCUMBRANCE_TYPE_ID 
AND        dt4.PERIOD_YEAR = FDW_TABLES_DB.OA3NF_GL_BALANCES_CDC.PERIOD_YEAR 
AND        dt4.SET_OF_BOOKS_ID = FDW_TABLES_DB.OA3NF_GL_BALANCES_CDC.SET_OF_BOOKS_ID 
AND        dt4.FINANCIAL_PLAN_ID = FDW_TABLES_DB.OA3NF_GL_BALANCES_CDC.FINANCIAL_PLAN_ID;
);