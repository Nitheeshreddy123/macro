INSERT INTO FDW_TABLES_DB.OA3NF_DB_CALENDAR
( 
   CALENDAR_DATE
   ,CALENDAR_MONTH
   ,CALENDAR_QUARTER
   ,CALENDAR_WEEK_ENDING
   ,CALENDAR_YEAR
   ,CALENDAR_PERIOD
   ,CALENDAR_PERIOD_NAME
   ,CALENDAR_PERIOD_QUARTER
) 
SELECT
   COALESCE(CALENDAR_DATE, CAST('01/01/1900' AS DATE FORMAT 'MM/DD/YYYY'))
   ,COALESCE(CAST(CAST((CALENDAR.CALENDAR_DATE (FORMAT 'M4')) AS VARCHAR(10)) AS VARCHAR(20)), 'NA')
   ,COALESCE(CAST('Q' || TRIM(CALENDAR.QUARTER_OF_YEAR) AS VARCHAR(20)), 'NA')
   ,CASE
          WHEN 6 = 1
             THEN CASE
                    WHEN calendar.day_of_week = 1
                       THEN calendar.calendar_date
                    WHEN calendar.day_of_week = 2
                       THEN calendar.calendar_date + 6
                    WHEN calendar.day_of_week = 3
                       THEN calendar.calendar_date + 5
                    WHEN calendar.day_of_week = 4
                       THEN calendar.calendar_date + 4
                    WHEN calendar.day_of_week = 5
                       THEN calendar.calendar_date + 3
                    WHEN calendar.day_of_week = 6
                       THEN calendar.calendar_date + 2
                    WHEN calendar.day_of_week = 7
                       THEN calendar.calendar_date + 1
                 END
          WHEN 6 = 2
             THEN CASE
                    WHEN calendar.day_of_week = 1
                       THEN calendar.calendar_date + 1
                    WHEN calendar.day_of_week = 2
                       THEN calendar.calendar_date
                    WHEN calendar.day_of_week = 3
                       THEN calendar.calendar_date + 6
                    WHEN calendar.day_of_week = 4
                       THEN calendar.calendar_date + 5
                    WHEN calendar.day_of_week = 5
                       THEN calendar.calendar_date + 4
                    WHEN calendar.day_of_week = 6
                       THEN calendar.calendar_date + 3
                    WHEN calendar.day_of_week = 7
                       THEN calendar.calendar_date + 2
                 END
          WHEN 6 = 3
             THEN CASE
                    WHEN calendar.day_of_week = 1
                       THEN calendar.calendar_date + 2
                    WHEN calendar.day_of_week = 2
                       THEN calendar.calendar_date + 1
                    WHEN calendar.day_of_week = 3
                       THEN calendar.calendar_date
                    WHEN calendar.day_of_week = 4
                       THEN calendar.calendar_date + 6
                    WHEN calendar.day_of_week = 5
                       THEN calendar.calendar_date + 5
                    WHEN calendar.day_of_week = 6
                       THEN calendar.calendar_date + 4
                    WHEN calendar.day_of_week = 7
                       THEN calendar.calendar_date + 3
                 END
          WHEN 6 = 4
             THEN CASE
                    WHEN calendar.day_of_week = 1
                       THEN calendar.calendar_date + 3
                    WHEN calendar.day_of_week = 2
                       THEN calendar.calendar_date + 2
                    WHEN calendar.day_of_week = 3
                       THEN calendar.calendar_date + 1
                    WHEN calendar.day_of_week = 4
                       THEN calendar.calendar_date
                    WHEN calendar.day_of_week = 5
                       THEN calendar.calendar_date + 6
                    WHEN calendar.day_of_week = 6
                       THEN calendar.calendar_date + 5
                    WHEN calendar.day_of_week = 7
                       THEN calendar.calendar_date + 4
                 END
          WHEN 6 = 5
             THEN CASE
                    WHEN calendar.day_of_week = 1
                       THEN calendar.calendar_date + 4
                    WHEN calendar.day_of_week = 2
                       THEN calendar.calendar_date + 3
                    WHEN calendar.day_of_week = 3
                       THEN calendar.calendar_date + 2
                    WHEN calendar.day_of_week = 4
                       THEN calendar.calendar_date + 1
                    WHEN calendar.day_of_week = 5
                       THEN calendar.calendar_date
                    WHEN calendar.day_of_week = 6
                       THEN calendar.calendar_date + 6
                    WHEN calendar.day_of_week = 7
                       THEN calendar.calendar_date + 5
                 END
          WHEN 6 = 6
             THEN CASE
                    WHEN calendar.day_of_week = 1
                       THEN calendar.calendar_date + 5
                    WHEN calendar.day_of_week = 2
                       THEN calendar.calendar_date + 4
                    WHEN calendar.day_of_week = 3
                       THEN calendar.calendar_date + 3
                    WHEN calendar.day_of_week = 4
                       THEN calendar.calendar_date + 2
                    WHEN calendar.day_of_week = 5
                       THEN calendar.calendar_date + 1
                    WHEN calendar.day_of_week = 6
                       THEN calendar.calendar_date
                    WHEN calendar.day_of_week = 7
                       THEN calendar.calendar_date + 6
                 END
          WHEN 6 = 7
             THEN CASE
                    WHEN calendar.day_of_week = 1
                       THEN calendar.calendar_date + 6
                    WHEN calendar.day_of_week = 2
                       THEN calendar.calendar_date + 5
                    WHEN calendar.day_of_week = 3
                       THEN calendar.calendar_date + 4
                    WHEN calendar.day_of_week = 4
                       THEN calendar.calendar_date + 3
                    WHEN calendar.day_of_week = 5
                       THEN calendar.calendar_date + 2
                    WHEN calendar.day_of_week = 6
                       THEN calendar.calendar_date + 1
                    WHEN calendar.day_of_week = 7
                       THEN calendar.calendar_date
                 END
       END
   ,COALESCE(CAST(CAST(CALENDAR.YEAR_OF_CALENDAR AS VARCHAR(256)) AS VARCHAR(256)), 'NA')
   ,trim(CALENDAR.YEAR_OF_CALENDAR) ||'-'|| ( trim(CALENDAR.MONTH_OF_YEAR (format '99')) )
   ,case
  when CALENDAR.month_of_year=1 then 'JAN' ||'-'|| substr(trim(CALENDAR.YEAR_OF_CALENDAR), 3, 2)
  when CALENDAR.month_of_year=2 then 'FEB' ||'-'|| substr(trim(CALENDAR.YEAR_OF_CALENDAR), 3, 2)
  when CALENDAR.month_of_year=3 then 'MAR' ||'-'|| substr(trim(CALENDAR.YEAR_OF_CALENDAR), 3, 2)
  when CALENDAR.month_of_year=4 then 'APR' ||'-'|| substr(trim(CALENDAR.YEAR_OF_CALENDAR), 3, 2)
  when CALENDAR.month_of_year=5 then 'MAY' ||'-'|| substr(trim(CALENDAR.YEAR_OF_CALENDAR), 3, 2)
  when CALENDAR.month_of_year=6 then 'JUN' ||'-'|| substr(trim(CALENDAR.YEAR_OF_CALENDAR), 3, 2)
  when CALENDAR.month_of_year=7 then 'JUL' ||'-'|| substr(trim(CALENDAR.YEAR_OF_CALENDAR), 3, 2)
  when CALENDAR.month_of_year=8 then 'AUG' ||'-'|| substr(trim(CALENDAR.YEAR_OF_CALENDAR), 3, 2)
  when CALENDAR.month_of_year=9 then 'SEP' ||'-'|| substr(trim(CALENDAR.YEAR_OF_CALENDAR), 3, 2)
  when CALENDAR.month_of_year=10 then 'OCT' ||'-'|| substr(trim(CALENDAR.YEAR_OF_CALENDAR), 3, 2)
  when CALENDAR.month_of_year=11 then 'NOV' ||'-'|| substr(trim(CALENDAR.YEAR_OF_CALENDAR), 3, 2)
  when CALENDAR.month_of_year=12 then 'DEC' ||'-'|| substr(trim(CALENDAR.YEAR_OF_CALENDAR), 3, 2)
  else null
end
   ,trim(CALENDAR.YEAR_OF_CALENDAR) ||'-Q'|| TRIM(CALENDAR.QUARTER_OF_YEAR)
 FROM 
   SYS_CALENDAR.CALENDAR
WHERE
   CALENDAR.YEAR_OF_CALENDAR > 1990
    AND CALENDAR.YEAR_OF_CALENDAR < 2040;