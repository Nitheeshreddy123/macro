update a
from FDW_tables_DB.OA3NF_GL_HIST_RATES_STU as a,
fdw_tables_DB.OA3NF_GL_FIN_PLAN as b
set gl_budget_key =b.FINANCIAL_PLAN_ID
where b.set_of_books_id=2248 and (case when a.BUDGET_TYPE='ACT' then 'Actual' else a.BUDGET_TYPE end)=b.FINANCIAL_PLAN_NAME;